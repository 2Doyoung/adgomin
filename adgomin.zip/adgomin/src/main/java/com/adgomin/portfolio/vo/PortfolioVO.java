package com.adgomin.portfolio.vo;

import com.adgomin.portfolio.entity.PortfolioEntity;

public class PortfolioVO extends PortfolioEntity {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
