package com.adgomin.main.entity;

public class MainEntity {

}
