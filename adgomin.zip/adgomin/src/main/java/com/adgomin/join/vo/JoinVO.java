package com.adgomin.join.vo;

import com.adgomin.join.entity.JoinEntity;

public class JoinVO extends JoinEntity {
    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
