package com.adgomin.user.entity;

public class UserEntity {
}
