package com.adgomin.user.vo;

public class UserVO {
}
