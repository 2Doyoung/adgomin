package com.adgomin.enums;

public enum CommonResult {
	FAILURE,
	SUCCESS,
	EMAIL_NOT_EXIST,
	PASSWORD_ERROR,
	SECESSION_USER,
	NO_CERTIFIED_USER
}
