package com.adgomin.manage.service;

public class ManageService {
}
