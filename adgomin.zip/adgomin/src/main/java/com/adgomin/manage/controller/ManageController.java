package com.adgomin.manage.controller;

public class ManageController {
}
