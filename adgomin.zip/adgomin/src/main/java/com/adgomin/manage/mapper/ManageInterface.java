package com.adgomin.manage.mapper;

public interface ManageInterface {
}
