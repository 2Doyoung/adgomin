package com.adgomin.media.entity;

public class MediaIntroduceEntity {
    private String email;
    private String mediaIntroduce;
    private String region;
    private String adCategory;
    private String mediaUrl;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMediaIntroduce() {
        return mediaIntroduce;
    }

    public void setMediaIntroduce(String mediaIntroduce) {
        this.mediaIntroduce = mediaIntroduce;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getAdCategory() {
        return adCategory;
    }

    public void setAdCategory(String adCategory) {
        this.adCategory = adCategory;
    }

    public String getMediaUrl() {
        return mediaUrl;
    }

    public void setMediaUrl(String mediaUrl) {
        this.mediaUrl = mediaUrl;
    }
}
