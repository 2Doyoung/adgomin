package com.adgomin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdgominApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdgominApplication.class, args);
	}

}
