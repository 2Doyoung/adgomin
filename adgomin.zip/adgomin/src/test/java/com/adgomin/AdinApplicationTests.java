package com.adgomin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdgominApplicationTests {

	@Test
	void contextLoads() {
	}

}
